function _validation()
{
	var pass=document.getElementById("uname").value;
	var pass=document.getElementById("password").value;
	var cpass=document.getElementById("cpassword").value;
	var email= document.getElementById("email").value;
	var phno= document.getElementById("contactNo").value;
	
	var evad = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
	var pvad=  /^[7-9]\d{9}$/;
	
	if(uname.length == 0 || pass.length == 0 || cpass.length == 0|| email.length == 0 || phno.length == 0 )
	{
		alert("All Field Requried,Enter value in the missing data");
	}
	else{
		if(pass.length<6 || pass.length>10)
		{
			alert("Enter password between 6 ,10 ");
		}
		else
		{
			if(cpass != pass)
			{
			alert("password and confirm password do not match")	;
			}
		if(!evad.test(email))
		{
			alert("Enter valid Email ID !");			
		}
		if(!pvad.test(phno))
		{
			alert("Enter valid number !");
		}
	
	
	
	}
		
		
		
		
	}
	
}